/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

import java.util.Objects;

/**
 *
 * @author coter
 */
public class Nodo {
    private Dominio dato;
    private Nodo siguiente;

    public Nodo() {//Vacio
    }

    public Nodo(Dominio dato) {//Con parametros
        this.dato = dato;
        this.siguiente = null;
    }
//get y set
    public Dominio getDato() {
        return dato;
    }

    public void setDato(Dominio dato) {
        this.dato = dato;
    }

    public Nodo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 53 * hash + Objects.hashCode(this.dato);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Nodo other = (Nodo) obj;
        return Objects.equals(this.dato, other.dato);
    }

    @Override
    public String toString() {
        return "Nodo{" + "dato=" + dato + '}';
    }    
}//Final
