/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class Cola {
    private Nodo frente;
    private Nodo fin;

    public Cola() { // C. vacio
    }

    public Cola(Nodo frente, Nodo fin) { // C. parametro
        this.frente = frente;
        this.fin = fin;
    }
    
    //Encolar (enqueue): agregar un objeto al final de la cola.
    public void enqueue(Dominio dato){
        Nodo nuevo = new Nodo(dato);
        if(isEmpty()){
            frente = nuevo;
        }else {
            fin.setSiguiente(nuevo);
        }
        fin = nuevo;
    }
    
    //Desencolar (dequeue): extraer y retornar el objeto situado al frente de la cola.
    public Dominio dequeue(){
        if(isEmpty()){
            return null;
        }
        Dominio dato = frente.getDato();
        frente = frente.getSiguiente();
        if (frente == null){
            fin = null;
        }
        return dato;
    }
    
    //Consultar frente (front o peek): obtener el objeto del frente sin retirarlo.
    public Dominio front(){
        if (isEmpty())
            return null;
        return frente.getDato();
    }
    
    //Verificar estado (isEmpty): determinar si la cola carece de elementos.
    public boolean isEmpty(){
        return frente == null;
    }
    
    //Obtener tamaño (size): devolver la cantidad de elementos presentes.
    public int size(){
        int cont = 0;
        Nodo actual = frente;
        while(actual != null){
            cont++;
            actual = actual.getSiguiente();
        }
        return cont;
    }
    
    //Vaciar (clear): restablecer las referencias para reiniciar la cola.
    public void clear(){
        frente = null;
        fin = null;
    }
    
    //Metodo auxiliar/extra
    public String mostrarCola() {
        if (isEmpty()) return "La cola está vacía";
        StringBuilder sb = new StringBuilder();
        Nodo actual = frente;
        int pos = 1;
        while (actual != null) {
            sb.append(pos).append(". ").append(actual.getDato()).append("\n");
            actual = actual.getSiguiente();
            pos++;
        }
        return sb.toString();
    }
}//Final
