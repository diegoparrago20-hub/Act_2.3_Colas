/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class Dominio {
    private int id;
    private String nombre;
    private String tipo;

    public Dominio() {//Vacio
    }

    public Dominio(int id, String nombre, String tipo) {//con parametros
        this.id = id;
        this.nombre = nombre;
        this.tipo = tipo;
    }
//get y set
    public int getid() {
        return id;
    }

    public void setid(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + this.id;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Dominio other = (Dominio) obj;
        return this.id == other.id;
    }

    @Override
    public String toString() {
        return "Servicio | " + " ID: " + id + " | Nombre: " + nombre + " | Tipo: " + tipo;
    }
    
}//Final
